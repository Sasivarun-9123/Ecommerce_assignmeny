from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),  # Add this for login page
    path('products/', views.product_list, name='product_list'),
    path('order/', views.order_page, name='order_page'),
]
